
#include "csapp.h"

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/time.h>

/* Global shared variable */
volatile long count = 0; /* Counter */

/* Thread routine */
void *thread(void *vargp)
{
  long i, niters = *((long *)vargp);

  for (i = 0; i < niters; i++) {
    count++;
  }

  return NULL;
}

int main (int argc, char **argv)
{
  long niters;

  if (argc < 2) {
    printf("usage: ./goodcount [NITERS]\n");
    exit(0);
  }

  pthread_t tid1, tid2;

  niters = atoi(argv[1]);

  /* Get start time */
  struct timeval start, end;
  gettimeofday(&start, NULL);

  Pthread_create(&tid1, NULL, thread, &niters);
  Pthread_create(&tid2, NULL, thread, &niters);

  Pthread_join(tid1, NULL);
  Pthread_join(tid2, NULL);

  /* Get and print end time */
  gettimeofday(&end, NULL);
  long seconds = (end.tv_sec - start.tv_sec);
  long micros = ((seconds * 1000000) + end.tv_usec) - (start.tv_usec);
  printf("%ld seconds and %ld microseconds\n", seconds, micros);

  /* Check result */
  if (count != (2 * niters))
    printf("BOOM! count=%ld\n", count);
  else
    printf("OK count=%ld\n", count);
  exit(0);
}
